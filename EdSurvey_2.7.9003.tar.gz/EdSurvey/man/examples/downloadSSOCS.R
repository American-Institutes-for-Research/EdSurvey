\dontrun{
#see instructions for downloading SSOCS Data
downloadSSOCS()
}