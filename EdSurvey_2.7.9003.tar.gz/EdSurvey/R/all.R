#' @importFrom LaF laf_open_fwf laf_open_csv close ncol nrow
#' @import Matrix
#' @import methods
#' @import lfactors
#' @import NAEPprimer

setGeneric("glm")
setGeneric("lm")
setGeneric("coef")
setGeneric("subset")

setOldClass("edsurvey.data.frame")
setOldClass("light.edsurvey.data.frame")
setOldClass("edsurvey.data.frame.list")

setAs("light.edsurvey.data.frame", "data.frame", function(from) {
  as.data.frame.light.edsurvey.data.frame(from)
})

setOldClass("edsurveyLm")
setOldClass("edsurveyLmList")
setOldClass("edsurveyGlm")
setOldClass("edsurveyGlmList")
