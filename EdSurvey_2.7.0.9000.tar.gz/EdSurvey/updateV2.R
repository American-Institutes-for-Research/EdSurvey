########################################################
# Purpose: Update external edsurvey directory from internal, and re-run pkgdown
# ToRun: mainExternal("~/GitHub/"), where "~/GitHub/" is your gitHub directory. 
#        I recommend editing your .Rprofile (file.edit(".Rprofile")) to load a variable githubHome, which
#        includes the path to your github directory. Then one can simply call mainExternal(), or source the file as is.
# Assumptions: This file assumes your internal EdSurvey directory is named "EdSurvey" and your external directory is named "EdSurvey_external. 
########################################################


transferExternal <- function(loc){
  
  # initiate edsurvey directories
  dir_int <- file.path(loc,"EdSurvey")
  dir_ext <- file.path(loc,"EdSurvey_external")
  
  # copy to external directory
  # TO DO: Tell user what packages to install, make zip file 
  devtools::build(dir_int,
                  path = dir_ext)
  
  # find edsurvey tag 
  tar <- grep("EdSurvey_.*\\.tar\\.gz", 
              list.files(dir_ext), 
               value = TRUE) 
  tar <- file.path(dir_ext, tar)
  
  # Unzip targ.z 
  untar(tar, exdir = dir_ext)
  
  # move contents up one node level 
  ed_files <- list.files(file.path(dir_ext,"EdSurvey"), full.names = TRUE)
  file.copy(ed_files, dir_ext, recursive = TRUE)
  
  # delete contents in sub directory 
  unlink(file.path(dir_ext,"EdSurvey"), recursive = TRUE)
  
  return(1)
}

siteExternal <- function(loc){
  # keep track of original directory 
  og_dir <- getwd()
  
  # initiate edsurvey directories
  dir_ext <- file.path(loc,"EdSurvey_external")
  
  # set working dir 
  setwd(dir_ext)
  # if docs exists, start pkgdown from start 
  dirs <- list.dirs(dir_ext, recursive = FALSE)
  if(any("docs" %in% dirs)){
    # run readme 
    rmarkdown::render("README.Rmd")
    # build site 
    pkgdown::build_site()
  } else {
    usethis::use_pkgdown()
    # run readme 
    rmarkdown::render("README.Rmd")
    # build site 
    pkgdown::build_site()
  }
  
  # remove docs from gitignore 
  fileConn<-file(".gitignore") 
  gitignore <- readLines(fileConn)
  docs_i <- grep("^docs$", gitignore)
  gitignore[docs_i] <- ""
  writeLines(gitignore, fileConn)
  close(fileConn)
  
  # reset directory 
  setwd(og_dir)
}

#main  
mainExternal <- function(loc = NULL) {
  # run transferExternal 
  # if loc is NULL check to see if github var is loaded
  if(is.null(loc)){
    if(exists("githubHome")){
      loc <- githubHome
    } else {
      # loc is NULL and no gitHub home 
      loc <- "~/GitHub/" # try looking for Github 
      if(dir.exists(loc)){
      } else {
        stop("Can't find location by default. You'll need to specify the loc argument to your GitHub folder.") # error if not found 
      }
    }
  }
  transferExternal(loc)
  siteExternal(loc)
}

# call main 
mainExternal()