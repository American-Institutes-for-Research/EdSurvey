library(testthat)
library(EdSurvey)
Sys.setenv(NOT_CRAN="")
test_check('EdSurvey')
