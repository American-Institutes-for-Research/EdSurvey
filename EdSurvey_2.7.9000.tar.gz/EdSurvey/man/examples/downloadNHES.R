\dontrun{
#view instructions to manually download NHES data
downloadNHES()
}