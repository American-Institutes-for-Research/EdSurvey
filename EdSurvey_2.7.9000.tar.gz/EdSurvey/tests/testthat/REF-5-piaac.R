## PIAAC ref

wt5REF <- c("Wald test:", 
            "----------", 
            "H0:", 
            "i_q04jVERY LITTLE = 1", 
            "i_q04jTO SOME EXTENT = 1", 
            "i_q04jTO A HIGH EXTENT = 1", 
            "i_q04jTO A VERY HIGH EXTENT = 1", 
            "", 
            "Chi-square test:", 
            "X2 = 45.6, df = 4, P(> X2) = 3e-09", 
            "", 
            "F test:", 
            "W = 10.6, df1 = 4, df2 = 42, P(> W) = 4.8e-06")

wt6REF <- c("Wald test:", 
            "----------", 
            "H0:", 
            "i_q04jVERY LITTLE = 1", 
            "i_q04jTO SOME EXTENT = 1", 
            "i_q04jTO A HIGH EXTENT = 1", 
            "i_q04jTO A VERY HIGH EXTENT = 1", 
            "", 
            "Chi-square test:", 
            "X2 = 45.7, df = 4, P(> X2) = 2.9e-09", 
            "", 
            "F test:", 
            "W = 11.0, df1 = 4, df2 = 77, P(> W) = 4.2e-07")

wt7REF <- c("Wald test:", 
            "----------", 
            "H0:", 
            "i_q04jVERY LITTLE = 1", 
            "i_q04jTO SOME EXTENT = 1", 
            "i_q04jTO A HIGH EXTENT = 1", 
            "i_q04jTO A VERY HIGH EXTENT = 1", 
            "", 
            "Chi-square test:", 
            "X2 = 51.1, df = 4, P(> X2) = 2.1e-10", 
            "", 
            "F test:", 
            "W = 12.8, df1 = 4, df2 = 4600, P(> W) = 2.4e-10")


