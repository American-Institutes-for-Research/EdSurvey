## ----code options, echo = FALSE----------------------------------------------------
options(width = 85)

## ----source package, eval=FALSE----------------------------------------------------
#  install.packages("EdSurvey")

## ----load package, results="hide", message=FALSE-----------------------------------
library(EdSurvey)

