library(testthat)
library(EdSurvey)
Sys.setenv(NOT_CRAN="true")
test_check('EdSurvey')
