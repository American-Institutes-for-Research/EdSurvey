\dontrun{
  #print the NHES survey information to the console for quick reference
  viewNHES_SurveyCodes()
}