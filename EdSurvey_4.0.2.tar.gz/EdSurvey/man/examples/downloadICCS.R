\dontrun{
# view instructions to manually download study data
downloadCivEDICCS()
}
